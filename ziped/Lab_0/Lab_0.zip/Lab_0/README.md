Lab 0: 3D Christmas Tree

creating a Christmas tree as a 3D object containing cone, cylinder, and sphere.

Changed files from the WebGL MDN tutorial, specifically sample 5. https://github.com/mdn/dom-examples/tree/475b80fe95744258629a03552907736e0d9b048f/webgl-examples/tutorial/sample5

Used DeepSeek to help with the code.