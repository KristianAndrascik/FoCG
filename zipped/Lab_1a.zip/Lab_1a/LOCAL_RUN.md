### Local Run Instructions

To run the application locally, you can use a simple HTTP server while developing your application. One of the easiest ways of doing this is using Python. Here are the steps to set it up:


python3 -m http.server